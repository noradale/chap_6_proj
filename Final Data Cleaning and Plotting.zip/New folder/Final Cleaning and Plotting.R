library(tidyverse)
#gettind rid of all the non-numeric values by replacing them with NA
PassRate = as.numeric(SOL$`2017-2018 Pass Rate`)
AdvPassRate = as.numeric(SOL$`2017-2018 Adv Pass Rate`)
SOL = mutate(SOL,PassRate)
SOL = mutate(SOL,AdvPassRate)
#removing all the NA values
SOL = SOL[!is.na(SOL$PassRate),]

#finding SOL pass and advance pass average from each county 
countyave = aggregate(SOL$PassRate,by = list(SOL$`Div Name`),FUN=mean)
countyadave = aggregate(SOL$AdvPassRate,by = list(SOL$`Div Name`),FUN=mean)
names(countyadave)[2]<-'AdvPassRate'
SOLAve = mutate(countyave,countyadave$AdvPassRate)
names(SOLAve)[1]<-'County'
names(SOLAve)[2]<-'PassRate'
names(SOLAve)[3]<-'AdvPassRate'

#deciding ranking criteria for children in poverty
povmax = max(CountyData$`Children in Poverty`)
povmin = min(CountyData$`Children in Poverty`)
povinterval = (povmax - povmin)/5
#creating the ranking column and adding it to the county data 
ChildPovertyRank = cut(CountyData$`Children in Poverty`, c(-Inf, povmin+ povinterval, povmin+ povinterval*2, povmin+povinterval*3,povmin+ povinterval*4, Inf), labels=  c("Very Low","Low","Moderate","High","Very High"))
CountyData = mutate(CountyData,ChildPovertyRank)

#deciding ranking criteria for high school graduation rate
gradmax = max(CountyData$`High School Graduation`)
gradmin = min(CountyData$`High School Graduation`)
gradinterval = (gradmax - gradmin)/5
#creating the ranking column and adding it to the county data 
GradRank = cut(CountyData$`High School Graduation`, c(-Inf, gradmin+gradinterval, gradmin+gradinterval*2, gradmin+gradinterval*3, gradmin+gradinterval*4, Inf), labels=  c("Very Low","Low","Moderate","High","Very High"))
CountyData = mutate(CountyData,GradRank)

FoodCol = CountyData$`Limited Access to Healthy Foods`[!is.na(CountyData$`Limited Access to Healthy Foods`)]
foodmax = max(FoodCol)
foodmin = min(FoodCol)
foodinterval = (foodmax-foodmin)/5

FoodRank = cut(CountyData$`Limited Access to Healthy Foods`, c(-Inf, foodmin+foodinterval, foodmin+foodinterval*2, foodmin+foodinterval*3, foodmin+foodinterval*4, Inf), labels=  c("Very Low","Low","Moderate","High","Very High"))
CountyData = mutate(CountyData,FoodRank)

#binning SOL data
PassCol = binned_data_final$`SOL PassRate`
passmax = max(PassCol)
passmin = min(PassCol)
passinterval = (passmax-passmin)/5

PassRank = cut(binned_data_final$`SOL PassRate`, c(-Inf, passmin+passinterval, passmin+passinterval*2, passmin+passinterval*3, passmin+passinterval*4, Inf), labels=  c("Very Low","Low","Moderate","High","Very High"))
binned_data_final= mutate(binned_data_final,PassRank)

AdvPassCol = binned_data_final$`SOL AdvPassRate`
advpassmax = max(AdvPassCol)
advpassmin = min(AdvPassCol)
advpassinterval = (advpassmax-advpassmin)/5

AdvPassRank = cut(binned_data_final$`SOL AdvPassRate`, c(-Inf, advpassmin+advpassinterval, advpassmin+advpassinterval*2, advpassmin+advpassinterval*3, advpassmin+advpassinterval*4, Inf), labels=  c("Very Low","Low","Moderate","High","Very High"))
binned_data_final= mutate(binned_data_final,AdvPassRank)


cor(as.numeric(complete_data$`SOL PassRate`),as.numeric(complete_data$`Children in Poverty`), use = "complete.obs", method =c("pearson","kendall","spearman"))
cor(as.numeric(complete_data$`SOL AdvPassRate`),as.numeric(complete_data$`Children in Poverty`), use = "complete.obs", method =c("pearson","kendall","spearman"))
cor(as.numeric(complete_data$`SOL PassRate`),as.numeric(complete_data$`Limited Access to Healthy Foods`), use = "complete.obs", method =c("pearson","kendall","spearman"))
cor(as.numeric(complete_data$`SOL AdvPassRate`),as.numeric(complete_data$`Limited Access to Healthy Foods`), use = "complete.obs", method =c("pearson","kendall","spearman"))
cor(as.numeric(complete_data$`SOL PassRate`),as.numeric(complete_data$`High School Graduation`), use = "complete.obs", method =c("pearson","kendall","spearman"))
cor(as.numeric(complete_data$`SOL AdvPassRate`),as.numeric(complete_data$`High School Graduation`), use = "complete.obs", method =c("pearson","kendall","spearman"))

library(RecordLinkage)

levenshteinSim(complete_data$PassRank,complete_data$FoodRank)
foodpass = levenshteinSim(complete_data$PassRank,complete_data$FoodRank)

povertypass = levenshteinSim(complete_data$PassRank,complete_data$ChildPovertyRank)

gradpass = levenshteinSim(complete_data$PassRank,complete_data$GradRank)

foodadvpass = levenshteinSim(complete_data$AdvPassRank,complete_data$FoodRank)

povertyadvpass = levenshteinSim(complete_data$AdvPassRank,complete_data$ChildPovertyRank)

gradadvpass = levenshteinSim(complete_data$AdvPassRank,complete_data$GradRank)

#plotting

library(ggplot2)
#child poverty
ggplot(data = complete_data, aes(x=complete_data$`Children in Poverty`,y=complete_data$`SOL PassRate`))+geom_point()+labs(x="Children in Poverty", y="SOL Pass Rate")

ggplot(data = complete_data, aes(x=complete_data$`Children in Poverty`,y=complete_data$`SOL AdvPassRate`))+geom_point()+labs(x="Children in Poverty", y="SOL Advanced Pass Rate")
#healthy food
ggplot(data = complete_data, aes(x=complete_data$`Limited Access to Healthy Foods`,y=complete_data$`SOL PassRate`))+geom_point()+labs(x="Limited Access to Healthy Food", y="SOL Pass Rate")

ggplot(data = complete_data, aes(x=complete_data$`Limited Access to Healthy Foods`,y=complete_data$`SOL AdvPassRate`))+geom_point()+labs(x="Limited Access to Healthy Food", y="SOL Advanced Pass Rate")
#high school graduation
ggplot(data = complete_data, aes(x=complete_data$`High School Graduation`,y=complete_data$`SOL PassRate`))+geom_point()+labs(x="High School Graduation Rate", y="SOL Pass Rate")

ggplot(data = complete_data, aes(x=complete_data$`High School Graduation`,y=complete_data$`SOL AdvPassRate`))+geom_point()+labs(x="High School Graduation Rate", y="SOL Advanced Pass Rate")




library(ggplot2)
library(usmap)

binned_data_final <- transform(binned_data_final, Child_Mortality = as.numeric(Child_Mortality))

#plotting and finding correlation between severe housing issues and SOL pass rate
ggplot(data=binned_data_final, aes(x=binned_data_final$Severe_Housing_Issues, y=binned_data_final$SOL.PassRate))+ geom_point() + labs(x="Severe Housing Issues",y="SOL Pass Rate")
SHIpass <- cor(binned_data_final$Severe_Housing_Issues,binned_data_final$SOL.PassRate)
SHIpass
#plotting and finding correlation between severe housing issues and SOL advanced pass rate
ggplot(data=binned_data_final, aes(x=binned_data_final$Severe_Housing_Issues, y=binned_data_final$SOL.AdvPassRate))+ geom_point() + labs(x="Severe Housing Issues",y="SOL Advanced Pass Rate")
SHIadvpass <- cor(binned_data_final$Severe_Housing_Issues,binned_data_final$SOL.AdvPassRate)
SHIadvpass
binned_data_final2 <- binned_data_final[-c(37,42,103),]

#plotting and finding correlation between child mortality and SOL pass rate
ggplot(data=binned_data_final2, aes(x=binned_data_final2$Child_Mortality, y=binned_data_final2$SOL.PassRate))+ geom_point() + labs(x="Child Mortality Rate",y="SOL Pass Rate")
CMpass <- cor(binned_data_final2$Child_Mortality, binned_data_final2$SOL.PassRate, use= "pairwise.complete.obs")
CMpass

#plotting and finding correlation between child mortality and SOL advanced pass rate
ggplot(data=binned_data_final2, aes(x=binned_data_final2$Child_Mortality, y=binned_data_final2$SOL.AdvPassRate))+ geom_point() + labs(x="Child Mortality Rate",y="SOL Advanced Pass Rate")
CMadvpass <-cor(binned_data_final2$Child_Mortality,binned_data_final2$SOL.AdvPassRate, use="pairwise.complete.obs")
CMadvpass

names(WhiteNW) <- c("County", "BinSeg","Percent_Segregated")
names(WhiteBlack) <- c("County", "BinSeg", "Percent_Segregated")
names(Data) <- c("County","Child_Mortality","CMBIN", "Severe_Housing_Issues","SHBIN","CountyPOP")



library(maps)
library(mapproj)

segmax = max(WhiteNW$Percent_Segregated)
segmin = min(WhiteNW$Percent_Segregated)
seginterval = (segmax-segmin)/5

Seg <- WhiteNW$Percent_Segregated
cut(Seg, c(-Inf, 10, 20,30,40, Inf), labels=  c("Very Low","Low","Moderate","High","Very High"))
WhiteNW$BinSeg <- cut(Seg, c(-Inf, 10, 20,30,40, Inf), labels=  c("Very Low","Low","Moderate","High","Very High"))

library(ggpubr)
ggscatter(binned_data_final, x = "sleep", y = "number_of_steps", 
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Hours of Sleep per Night", ylab = "Steps per Day")


Seg <- WhiteBlack$Percent_Segregated
cut(Seg, c(-Inf, 10, 20,30,40, Inf), labels=  c("Very Low","Low","Moderate","High","Very High"))
WhiteBlack$BinSeg <- cut(Seg, c(-Inf, 10, 20,30,40, Inf), labels=  c("Very Low","Low","Moderate","High","Very High"))

Seg <- Data$Child_Mortality
cut(Seg, c(-Inf, .25, .5, .75, .9, Inf), labels=  c("Very Low","Low","Moderate","High","Very High"))
Data$CMBIN <- cut(Seg, c(-Inf, .25, .5, .75, .9, Inf), labels=  c("Very Low","Low","Moderate","High","Very High"))

Seg <- Data$Severe_Housing_Issues
cut(Seg, c(-Inf, .10, .13, .16, .19, Inf), labels=  c("Very Low","Low","Moderate","High","Very High"))
Data$SHBIN <- cut(Seg, c(-Inf, .10, .13, .16, .19, Inf), labels=  c("Very Low","Low","Moderate","High","Very High"))


c(-Inf, segmin+seginterval, segmin+seginterval*2, segmin+seginterval*3, segmin+seginterval*4, Inf)

library(ggplot2)
ggplot(WhiteNW, aes(x = County, fill = BinSeg)) +
  theme_bw() +
  geom_bar() +
  labs( y = "Segregation", x = "County") +
  scale_fill_discrete(name = 'WhiteNW', h = c(360,180) + 25, c = 100, l=65, h.start = 0,  direction = 1, na.value = "grey50") 

library(maps)
library(mapproj)

Data$WhiteNonWhiteBin <- WhiteNW$BinSeg


library(ggplot2)
library(usmap)

#Changing names to be one word
names(Binned_Data_Final)[17] <- ('SOL_Pass_Rate')
names(Binned_Data_Final)[18] <- ('SOL_Advance_Rate')
#Making the 'NA' values into actually being a NA value
Binned_Data_Final$WhiteBlackSeg[Binned_Data_Final$WhiteBlackSeg == 'NA'] <- NA
#making the column numeric so you can do correlation
Binned_Data_Final[7] <- as.numeric(Binned_Data_Final$WhiteBlackSeg)


#plotting and finding correlation between White Black Segregation and SOL pass rates
ggplot(data=Binned_Data_Final, aes(x=Binned_Data_Final$WhiteBlackSeg, y=Binned_Data_Final$SOL_Pass_Rate))+ geom_point()
cor(Binned_Data_Final$WhiteBlackSeg,Binned_Data_Final$SOL_Pass_Rate, use="pairwise.complete.obs")


#plotting and finding correlation between White Black Segregation and SOL advanced pass rate
ggplot(data=Binned_Data_Final, aes(x=Binned_Data_Final$WhiteBlackSeg, y=Binned_Data_Final$SOL_Advance_Rate))+ geom_point()
cor(Binned_Data_Final$WhiteBlackSeg,Binned_Data_Final$SOL_Advance_Rate, use="pairwise.complete.obs")

#plotting and finding correlation between White NonWhite and SOL pass rate
ggplot(data=Binned_Data_Final, aes(x=Binned_Data_Final$WhiteNonWhiteSeg, y=Binned_Data_Final$SOL_Pass_Rate))+ geom_point()
#making the 'NA's into NA values and making the column numeric
Binned_Data_Final$WhiteNonWhiteSeg[Binned_Data_Final$WhiteNonWhiteSeg == 'NA'] <- NA
Binned_Data_Final[9] <- as.numeric(Binned_Data_Final$WhiteNonWhiteSeg)

cor(Binned_Data_Final$WhiteNonWhiteSeg,Binned_Data_Final$SOL_Pass_Rate, use="pairwise.complete.obs")

#plotting and finding correlation between White NonWhite and SOL advanced pass rate
ggplot(data=Binned_Data_Final, aes(x=Binned_Data_Final$WhiteNonWhiteSeg, y=Binned_Data_Final$SOL_Advance_Rate))+ geom_point()
cor(Binned_Data_Final$WhiteNonWhiteSeg,Binned_Data_Final$SOL_Advance_Rate, use="pairwise.complete.obs")
library("ggpubr")
ggdensity(Binned_Data_Final$WhiteBlackSeg, 
          main = "Density plot",
          xlab = "Tooth length")

ggqqplot(Binned_Data_Final$WhiteNonWhiteSeg)

shapiro.test(Binned_Data_Final$WhiteNonWhiteSeg)
